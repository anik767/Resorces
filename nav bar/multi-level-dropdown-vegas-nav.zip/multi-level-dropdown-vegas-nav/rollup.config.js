import resolve from "@rollup/plugin-node-resolve";
import commonjs from "@rollup/plugin-commonjs";
import replace from "@rollup/plugin-replace";
import babel from "@rollup/plugin-babel";
import filesize from "rollup-plugin-filesize";
import {eslint} from "rollup-plugin-eslint";
import {terser} from "rollup-plugin-terser";
import banner from "rollup-plugin-banner";
import pkg from "./package.json";

const config = [];
const files = ["VGNav", "VGSidebar", "VGFlipList"];

for (const file_name of files) {
	let input_file;
	let output_file;

	const parts = file_name.split(".");
	const component = parts[0];
	const plugin = parts[1] || false;

	if (plugin) {
		input_file = `${component}/plugins/${plugin}/${plugin}.js`;
		output_file = `${component.toLowerCase()}.${plugin.toLowerCase()}`;
	} else {
		input_file = `${component}/index.js`;
		output_file = component.toLowerCase();
	}

	config.push({
		input: `src/${input_file}`,
		output: [
			{
				file: `dist/${output_file}.js`,
				format: "iife",
				name: "window",
				esModule: false,
				extend: true,
				exports: "named",
			},
		],
		plugins: [
			commonjs(),
			eslint(),
		],
	});

	config.push({
		input: `src/${input_file}`,
		output: [
			{
				file: `dist/${output_file}.min.js`,
				format: "umd",
				name: "window",
				esModule: false,
				extend: true,
				exports: "named",
			},
		],
		plugins: [
			babel({
				babelrc: false,
				exclude: "node_modules/**",
				presets: [["@babel/preset-env"]],
				babelHelpers: "bundled",
			}),
			resolve(),
			commonjs(),
			eslint(),
			replace({ __VERSION__: pkg.version, preventAssignment: true }),
			terser(),
			banner(`@vegas-${file_name} v${pkg.version}`),
			filesize({ showMinifiedSize: false }),
		],
	});
}

export default config;