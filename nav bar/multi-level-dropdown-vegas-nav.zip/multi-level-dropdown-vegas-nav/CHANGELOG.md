# VEGAS-NAV 3.2.12 (OKTOBER 24, 2023)
* Auto positioning of the drop-down list (default: true)
* bugs fixed

# VEGAS-NAV 3.2.5 (JUNE 29, 2023)
* bugs fixed

# VEGAS-NAV 3.1.5 (DECEMBER 13, 2022)
* bugs fixed

# VEGAS-NAV 3.1.1 (NOVEMBER 10, 2022)
* automatic transfer of links to the drop-down menu if the total width of all links is greater than the main container. The "move" parameter has been introduced

# VEGAS-NAV 3.1.0 (SEPTEMBER 27, 2022)
* custom hamburger and fixes

* # VEGAS-NAV 3.0.6 (JUNE 29, 2022)
* VGSpy removed from this project

# VEGAS-NAV 3.0.5 (JUNE 22, 2022)
* bugs fixed

* # VEGAS-NAV 3.0.0 (JUNE 22, 2022)
* Completely rewritten, bugs fixed.
* Added VGSidebar and VGSpy plugin

# VEGAS-NAV 2.0.5 (MAY 18, 2022)
* Export Public Api

# VEGAS-NAV 2.0.3 (JULY 22, 2021)
* Added heading for mobile navigation. Specify in the settings {mobileTitle: 'Navigation'}

# VEGAS-NAV 2.0.0 (NOVEMBER 09, 2020)
* Changed plugin markup, see documentation
* Added callbacks
* Fixed bugs 

# VEGAS-NAV 1.1.5 (JULY 24, 2020)
* Minor bugs fixed

# VEGAS-NAV 1.1.4 (JULY 06, 2020)
* Adapted layout in Firefox 72.x.x fixed

# VEGAS-NAV 1.1.2 (JUNE 02, 2020)
* Minor bugs fixed 

# VEGAS-NAV 1.1.1 (MAY 08, 2020)
* Minor bugs fixed 

# VEGAS-NAV 1.1.0 (MARCH 24, 2020)
* Toggle customization 
* Minor bugs fixed 

# VEGAS-NAV 1.0.9 (MARCH 17, 2020)
* Opening the expanded menu on hover 

# VEGAS-NAV 1.0.8 (MARCH 10, 2020)
* Minor bugs fixed 

# VEGAS-NAV 1.0.7 (MARCH 10, 2020)
* The choice of expanding the menu in the sidebar or in the collapse

# VEGAS-NAV 1.0.6 (MARCH 04, 2020)
* Open sidebar left or right
* Custom sidebar 

# VEGAS-NAV 1.0.5 (MARCH 02, 2020)
* Custom sidebar width
* Minor bugs fixed 

# VEGAS-NAV 1.0.4 (FEB 27, 2020)
* Edit README
* Minor bugs fixed 

# VEGAS-NAV 1.0.0 (FEB 27, 2020)
* Init release
