import {VGNav} from "./src/VGNav";

export {
	VGNav
}