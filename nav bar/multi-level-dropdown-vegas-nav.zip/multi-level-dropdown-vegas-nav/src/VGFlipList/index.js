/**
 * --------------------------------------------------------------------------
 * Export Public Api
 * Автор: Vegas Studio
 * Лицензия: смотри LICENSE.md
 * --------------------------------------------------------------------------
 */

import VGFlipList from "./js/VGFlipList";

export {
	VGFlipList
};
